package Enums;

public enum Tamanho
{
    PEQUENO,
    MEDIO,
    GRANDE
}
