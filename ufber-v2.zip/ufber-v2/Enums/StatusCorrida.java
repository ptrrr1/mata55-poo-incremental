package Enums;

public enum StatusCorrida {
    SOLICITADA,
    ACEITA,
    EM_ANDAMENTO,
    FINALIZADA,
    CANCELADA
}