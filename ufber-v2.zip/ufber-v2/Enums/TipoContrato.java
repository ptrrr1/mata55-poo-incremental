package Enums;

public enum TipoContrato {
    PRO_LABORE,
    CARONA,
    ENTREGA
}